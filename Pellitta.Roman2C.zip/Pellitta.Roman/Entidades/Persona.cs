﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public enum Posicion
    {
        Arquero,
        Defensor,
        Central,
        Delantero,

    }
    public abstract class Persona
    {
        

        private string apellido;
        private int dni;
        private int edad;
        private string nombre;
        
        public string Apellido
        {
            get
            {
                return this.apellido;
            }
        }
        public int Dni
        {
            get
            {
                return this.dni;
            }
        }
        public int Edad
        {
            get
            {
                return this.edad;
            }
        }
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
        }
        /// <summary>
        /// muestra todos los campos de la clase
        /// </summary>
        /// <returns></returns>
        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(string.Format("Nombre: {0}", this.Nombre));
            sb.AppendLine(string.Format("Apellido: {0}", this.Apellido));
            sb.AppendLine(string.Format("Edad: {0}", this.Edad));
            sb.AppendLine(string.Format("D.N.I.: {0}", this.Dni));

            return sb.ToString();

        }
        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="edad"></param>
        /// <param name="dni"></param>
        public Persona(string nombre,string apellido,int edad, int dni)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
            this.dni = dni;
        }
        /// <summary>
        /// funcion abstracta
        /// </summary>
        /// <returns></returns>
        public abstract bool ValidarAptitud();
    }
}
