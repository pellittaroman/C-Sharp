﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DirectorTecnico : Persona
    {
        private int añosExperiencia;

        public int AñosExperiencia
        {
            get
            {
                return this.añosExperiencia;
            }
            set
            {
                this.añosExperiencia = value;
            }
        }
        public DirectorTecnico(string nombre,string apellido,int edad,int dni,int añosExperiencia)
            :base(nombre,apellido,edad,dni)
        {
            AñosExperiencia = añosExperiencia;
        }
        /// <summary>
        /// valida si cumple con ciertos requisitos
        /// </summary>
        /// <returns></returns>
        public override bool ValidarAptitud()
        {
            bool ok = false;
            if(this.AñosExperiencia<65 && this.AñosExperiencia>=2)
            {
                ok = true;
            }
            return ok;
        }
        /// <summary>
        /// muestra datos de la clase
        /// </summary>
        /// <returns></returns>
        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.AppendLine(string.Format("Años de Experiencia: ",this.AñosExperiencia.ToString()));
            
                return sb.ToString();
        }
    }
}
