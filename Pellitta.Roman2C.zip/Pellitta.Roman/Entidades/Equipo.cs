﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Equipo
    {
        const int cantidadMaximaJugadores=6;
        private DirectorTecnico directorTecnico;
        private List<Jugador> jugadores;
        private string nombre;
        public DirectorTecnico DirectorTecnico
        {
            set
            {
                if(directorTecnico.ValidarAptitud())
                {
                    this.directorTecnico = value;
                }
                else
                {
                    this.directorTecnico = null;
                }
            }
        }
        public string Nombre
        {
            get
            {
               return this.nombre;
            }
        }
        private Equipo()
        {
            jugadores = new List<Jugador>();
        }
        public Equipo(string nombre)
            :this()
        {
            this.nombre = nombre;
        }
        public static explicit operator string(Equipo e)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(string.Format("Nombre del equipo: {0}", e.Nombre));
            if(e.directorTecnico==null)
            {
                sb.AppendLine("Sin DT Asignado");
            }
            else
            {
                sb.AppendLine(string.Format("Director Tecnico:\n {0}", e.directorTecnico.Mostrar()));
            }
            sb.AppendLine("Jugadores:");
            foreach (Jugador j in e.jugadores)
            {

                sb.AppendLine(j.Mostrar());
            }
            return sb.ToString();
        }
        public static bool operator ==(Equipo e,Jugador j)
        {
            bool ok = false;
            foreach(Jugador aux in e.jugadores)
            {
                if(aux==j)
                {
                    ok = true;
                    break;
                }
            }
            return ok;
        }
        public static bool operator !=(Equipo e,Jugador j)
        {
            return !(e == j);
        }
        public static Equipo operator +(Equipo e,Jugador j)
        {
            if(e==j)
            {
                return e;
            }
            if (e.jugadores.Count>=6)
            {
                return e;
            }
            if(j.ValidarAptitud())
            {
                e.jugadores.Add(j);
            }
            return e;
        }
        public static bool ValidarEquipo(Equipo e)
        {
            bool ok = false;
            if (e.directorTecnico != null)
            {
                if (e.jugadores.Count == cantidadMaximaJugadores)
                {
                    
                    int sumaArquero=0;
                    int sumaDefensor=0;
                    int sumaCentral=0;
                    int sumaDelantero=0;
                    for(int i=0;i<e.jugadores.Count;i++)
                    {
                        switch(e.jugadores.ElementAt(i).Posicion)
                        {
                            case Posicion.Arquero:
                                sumaArquero++;
                                break;
                            case Posicion.Defensor:
                                sumaDefensor++;
                                break;
                            case Posicion.Central:
                                sumaCentral++;
                                break;
                            case Posicion.Delantero:
                                sumaDelantero++;
                                break;
                        }
                        if(sumaArquero==1)
                        {
                            if(sumaCentral!=0&&sumaDefensor!=0&&sumaDelantero!=0)
                            {
                                ok = true;
                            }
                                
                        }
                    }
                }
            }
            return ok;
        }

        
    }
}
