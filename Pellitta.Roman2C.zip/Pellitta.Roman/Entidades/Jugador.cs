﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Jugador: Persona
    {
        private float altura;
        private float peso;
        private Posicion posicion;

        public float Altura
        {
            get
            {
                return this.altura;
            }
        }
        public  float Peso
        {
            get
            {
                return this.peso;
            }
        }
        public  Posicion Posicion
        {
            get
            {
                return this.posicion;
            }
        }

        public Jugador(string nombre,string apellido,int edad,int dni, float peso,float altura,Posicion posicion)
            :base(nombre,apellido,edad,dni)
        {
            this.altura = altura;
            this.peso = peso;
            this.posicion = posicion;
        }
        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.AppendLine(string.Format("Altura: {0}", this.Altura.ToString()));
            sb.AppendLine(string.Format("Peso: {0}", this.Peso.ToString()));
            sb.AppendLine(string.Format("Posicion: {0}", this.Posicion.ToString()));

            return sb.ToString();

        }
        public bool ValidarEstadoFisico()
        {
            bool ok = false;
            float imc;
            imc = this.Peso / (this.Altura * this.Altura);
            if(imc<=25&&imc>=18.5)
            {
                ok = true;
            }
            return ok;
        }

        public override bool ValidarAptitud()
        {
            bool ok=false;

            if (Edad<40&&ValidarEstadoFisico()==true)
            {
                ok = true;
            }
            return ok;
        }

    }
}
