﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio16
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno nuevo = new Alumno();
            byte nota1;
            byte nota2;
            Console.WriteLine("Ingrese legajo:");
            nuevo.legajo = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese Nombre:");
            nuevo.nombre = Console.ReadLine();
            Console.WriteLine("Ingrese Apellido:");
            nuevo.apellido = Console.ReadLine();
            Console.WriteLine("Ingrese nota del primer parcial:");
            nota1 = byte.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese nota del segundo parcial:");
            nota2 = byte.Parse(Console.ReadLine());
            nuevo.Estudiar(nota1, nota2);
            nuevo.CalcularFinal();
            nuevo.Mostrar();
            Console.ReadKey();
        }
    }
}
