﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio16
{
    public class Alumno
    {   
        private byte _nota1;
        private byte _nota2;
        private float _notaFinal;
        public string apellido;
        public string nombre;
        public int legajo;

        
        public void Estudiar(byte notaUno, byte notaDos)
        {
            this._nota1 = notaUno;
            this._nota2 = notaDos;
            

        }
        public void CalcularFinal()
           
        {
            Random nota= new Random();
            if(this._nota1>=4 && this._nota2>=4)
            {
                this._notaFinal = nota.Next(4, 10);
            }
            else
            {
                this._notaFinal = -1;
            }

        }
        public void Mostrar()
        {
            Console.WriteLine("Legajo " + legajo);
            Console.WriteLine("Nombre: " + nombre);
            Console.WriteLine("Apellido " + apellido);
            if(this._notaFinal!= -1)
            {
                Console.WriteLine("Nota Final " + this._notaFinal);
            }
            else
            {
                Console.WriteLine("El alumno desaprobo");
            }
        }
    }
}
