﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Parte2;


namespace Ejercicio17
{
    class Program
    {
        static void Main(string[] args)
        {
            Boligrafo azul = new Boligrafo(100,ConsoleColor.Blue);
            Boligrafo rojo = new Boligrafo(50, ConsoleColor.Red);

            string texto;
            if (azul.Pintar(3, out texto) == true)
            {
                Console.BackgroundColor = azul.GetColor();
                Console.WriteLine(texto);
            }
            if (rojo.Pintar(33, out texto) == true)
            {
                Console.BackgroundColor = rojo.GetColor();
                Console.WriteLine(texto);
            }
            if (rojo.Pintar(16, out texto) == true)
            {
                Console.BackgroundColor = rojo.GetColor();
                Console.WriteLine(texto);
            }
            if (rojo.Pintar(3, out texto) == true)
            {
                Console.BackgroundColor = rojo.GetColor();
                Console.WriteLine(texto);
            }
            if (azul.Pintar(73, out texto) == true)
            {
                Console.BackgroundColor = azul.GetColor();
                Console.WriteLine(texto);
            }
            Console.ReadKey();


        }
    }
}
