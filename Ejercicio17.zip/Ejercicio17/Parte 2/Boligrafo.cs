﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio17
{
     public class Boligrafo
    {
        public const short cantidadTintaMaxima = 100;
        private ConsoleColor color = new ConsoleColor();
        private short tinta;

        public Boligrafo(short tinta, ConsoleColor color)
        {
            this.tinta = tinta;
            this.color = color;
        }

        public ConsoleColor GetColor()
        {
            return this.color;
        }

        public short GetTinta()
        {
            return this.tinta;
        }

        private void SetTinta(short tinta)
        {
            int aux= this.tinta + tinta;
            if (aux <= 100 && aux >= 0)
            {
                this.tinta =(short) aux; 
            }
        }

        public void Recargar()
        {
            this.tinta = cantidadTintaMaxima;
        }

        public bool Pintar(int gasto, out string dibujo)
        {
            bool ok = false;
            dibujo = "";
            
           

            for (int i = 0; i < gasto; i++)
            {

                if (i < GetTinta()&& gasto < GetTinta())
                {
                    dibujo += '*';

                    ok = true;
                }
            }


            

            return ok;
        }
    }
}
