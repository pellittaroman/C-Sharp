using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Profesor:Persona
    {
        private DateTime fechaDeIngreso;

        public int Antiguedad
        {
            get
            {
                int retorno;   
                DateTime aux = DateTime.Now;
                retorno= fechaDeIngreso.Day-aux.Day;
                return retorno;
            }
        }
        public override string ExponerDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ExponerDatos());
            sb.AppendLine(this.fechaDeIngreso.ToString());
            return sb.ToString();
        }
        public override bool ValidarDocumentacion(string Doc)
        {
            bool ok = false;
            int aux;
            if (Doc.Length == 9)
            {
                

                for (int i = 0; i < Doc.Length; i++)
                {
                   
                    if (Doc[2] == '-' || Doc[7] == '-')
                    {
                        ok = true;
                    }
                    else
                    {
                        ok = false;
                    }

                }
            }
            return ok;

        }
        public Profesor(string nombre, string apellido, string documento)
            :base(nombre,apellido,documento)
        {
            
        }
        public Profesor(string nombre, string apellido, string documento,DateTime fechaDeIngreso)
            :base(nombre,apellido,documento)
        {
            this.fechaDeIngreso = fechaDeIngreso;
        }
    }
}
