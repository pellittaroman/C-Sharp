﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Alumno:Persona
    {
        private short anio;
        private Divisiones division;

        public string AnioDivision
        {
            get
            {
                return this.anio.ToString() + "º" + this.division.ToString();
            }
        }
        public override string ExponerDatos()
        {
            
                StringBuilder sb = new StringBuilder();
                return sb.AppendFormat("{0}\n", this.AnioDivision).ToString()+ base.ExponerDatos();
            
        }
        public override bool ValidarDocumentacion(string Doc)
        {
            bool ok = true;
            int aux;
            if(Doc.Length==9)
            {
                
                //ok = false;
            for (int i=0;i<Doc.Length;i++)
            {
                    if (Doc[2] == '-' || Doc[7] == '-')
                    {
                        ok = true;
                    }
                    else
                    {
                        ok = false;
                    }

                }
            }
            return ok;
            
        }
        public Alumno(string nombre,string apellido,string documento,short anio, Divisiones division)
            :base(nombre,apellido,documento)
        {
            this.anio = anio;
            this.division = division;
        }

    }
}
