﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Curso
    {
        private List<Alumno> alumnos;
        private short anio;
        Divisiones division;
        Profesor profesor;

        private Curso()
        {
            this.alumnos = new List<Alumno>();
        }
        public Curso(short anio, Divisiones division, Profesor profesor)
            :this()
        {
            this.profesor = profesor;
            this.anio = anio;
            this.division = division;
        }

        public string AnioDivision
        {
            get
            {
                return this.anio.ToString() + "º" + this.division.ToString(); 
            }
        }
       public static explicit operator string(Curso c)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Curso: " + c.AnioDivision);
            sb.AppendLine("Profesor:\n" + c.profesor.ExponerDatos());
            sb.AppendLine("Alumnos: ");
            foreach(Alumno auxiliar in c.alumnos)
            {
                sb.AppendLine(auxiliar.ExponerDatos());
            }
            return sb.ToString();
        }
        
        public static bool operator ==(Curso c, Alumno a)
        {
            bool ok;
            if(a.AnioDivision==c.AnioDivision)
            {
                ok = true;
            }
            else
            {
                ok = false;
            }
            return ok;
        }
        public static bool operator !=(Curso c, Alumno a)
        {
            return !(c == a);
        }
        public static Curso operator +(Curso c, Alumno a)
        {
            if(c==a)
            {
                c.alumnos.Add(a);
            }
            return c;
        }
      

    }
}
