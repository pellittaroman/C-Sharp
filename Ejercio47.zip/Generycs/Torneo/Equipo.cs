﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Campeonato
{
    public abstract class Equipo
    {
        private string nombre;
        private DateTime creacion;

        public static bool operator ==(Equipo a, Equipo b)
        {
            bool ok = false;
            if(a.nombre==b.nombre&& a.creacion==b.creacion)
            {
                ok = true;
            }
            return ok;
        }
        public static bool operator !=(Equipo a, Equipo b)
        {
            return !(a == b);
        }
        public Equipo(string nombre,DateTime creacion)
        {
            this.creacion = creacion;
            this.nombre = nombre;
        }
        public string Ficha(Equipo a)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0} creado en {1}", a.nombre, a.creacion.Year);
            return sb.ToString();
        }
    }
}
