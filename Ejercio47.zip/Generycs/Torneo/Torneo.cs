﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Campeonato

{
    public class Torneo<T> where T : Equipo
    {
        private string nombre;
        List<T> lista;
        private Torneo()
        {
            this.lista = new List<T>();
        }
        public Torneo(string nombre)
            :this()
        {
            this.nombre = nombre;
        }
        public static bool operator ==(Torneo<T> torneo, T e)
        {
            bool ok = false;

            foreach (T a in torneo.lista)
            {
                if(a==e)
                {
                    ok = true;
                    break;
                }
            }
            return ok;
        
        }
        public static bool operator !=(Torneo<T> torneo,T e)
        {
            return !(torneo == e);
        }
        public static Torneo<T> operator +(Torneo<T> torneo, T e)
        {
            

            if(torneo!=e)
            {
                torneo.lista.Add(e);
                
            }
            return torneo;

        }
        public string Mostrar(Torneo<T> torneo)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(string.Format("Nombre del torneo: {0}", this.nombre));
            sb.AppendLine("Equipos participantes : ");
            foreach (T a in torneo.lista)
            {
                sb.AppendLine(a.Ficha(a));
            }
            return sb.ToString();
        }
        private string CalcularResultado(T a, T b)
        {
            Random goles = new Random();
            StringBuilder sb = new StringBuilder();
            sb.Append(string.Format("{0} {1}-{2} {3}", a.Ficha(a),goles.Next(150),goles.Next(150),b.Ficha(b)));

            return sb.ToString();

        }
        public string JugarPartido(Torneo<T> torneo)
        {
            Random index = new Random();
            string retorno;
            T a;
            T b;
            a= torneo.lista.ElementAt(index.Next(0,torneo.lista.Count-1));
            b= torneo.lista.ElementAt(index.Next(0, torneo.lista.Count - 1));
            while(a==b)
            {
                b = torneo.lista.ElementAt(index.Next(0, torneo.lista.Count - 1));
            }
            retorno= CalcularResultado(a, b);
            return retorno;
        }
    }
}
