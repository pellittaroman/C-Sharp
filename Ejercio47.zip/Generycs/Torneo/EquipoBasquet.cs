﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Campeonato
{
    public class EquipoBasquet: Equipo
    {
        public EquipoBasquet(string nombre, DateTime creacion)
            :base(nombre, creacion)
        {

        }
    }
}
