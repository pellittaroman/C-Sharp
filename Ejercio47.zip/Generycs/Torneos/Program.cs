﻿using System;
using Campeonato;

namespace Torneos
{
    class Program
    {
        static void Main(string[] args)
        {
            Torneo<EquipoBasquet> torneoBasket = new Torneo<EquipoBasquet>("Tres de Tres");
            Torneo<EquipoFutbol> torneoFutbol = new Torneo<EquipoFutbol>("De caño vale 5");
            DateTime fecha;
            EquipoFutbol uno = new EquipoFutbol("Boca", fecha = new DateTime(1905, 04, 03));
            EquipoFutbol dos = new EquipoFutbol("Boca Unidos", fecha = new DateTime(1975, 08, 23));
            EquipoFutbol tres = new EquipoFutbol("Berazategui", fecha = new DateTime(1895, 04, 13));
            EquipoFutbol tress = new EquipoFutbol("Boca", fecha = new DateTime(1905, 04, 03));
            EquipoBasquet unob = new EquipoBasquet("Boca", fecha = new DateTime(1915, 08, 30));
            EquipoBasquet dosb= new EquipoBasquet("Boca", fecha = new DateTime(1925, 08, 25));
            EquipoBasquet tresb = new EquipoBasquet("Boca", fecha = new DateTime(1905, 04, 03));
            torneoBasket+=unob;
            torneoBasket += dosb;
            torneoBasket += tresb;
            Console.WriteLine(torneoBasket.Mostrar(torneoBasket));
            Console.WriteLine(torneoBasket.JugarPartido(torneoBasket));
            Console.WriteLine("");
            Console.ReadKey();
            torneoFutbol += uno;
            torneoFutbol += dos;
            torneoFutbol += tres;
            torneoFutbol += tress;
            torneoFutbol += dos;
            Console.WriteLine(torneoFutbol.Mostrar(torneoFutbol));
            Console.WriteLine(torneoFutbol.JugarPartido(torneoFutbol));
            Console.ReadKey();
        }
    }
}
