﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio29
{
    public class Jugador
    {
        private long dni;
        private string nombre;
        private int partidosJugadores;
        private float promediosGoles;
        private int totalGoles;

        private Jugador()
        {

        }
        public Jugador(int dni, string nombre)
        {
            this.dni = dni;
            this.nombre = nombre;
        }
        public Jugador(int dni, string nombre, int totalGoles, int totalPartidos)
            :this(dni,nombre)
        {
            this.partidosJugadores = totalPartidos;
            this.totalGoles = totalGoles;
        }
        public float GetPromedioGoles()
        {
            return this.promediosGoles = this.totalGoles / this.partidosJugadores;
        }
        public  string MostrarDatos(Jugador j)
        {
            return "" + j.dni + j.nombre + j.partidosJugadores + j.totalGoles + j.GetPromedioGoles();
        }
        public static bool operator ==(Jugador j1, Jugador j2)
        {
            bool retorno = false;
            if (j1.dni == j2.dni)
            {
                retorno = true;
            }
            return retorno;
        }


        public static bool operator !=(Jugador j1, Jugador j2)
        {
            return !(j1 == j2);
        }
    }
}
