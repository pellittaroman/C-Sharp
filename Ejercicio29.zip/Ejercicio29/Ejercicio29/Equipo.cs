﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio29
{
    public class Equipo
    {
        private short cantidadDeJugadores;
        private string nombre;
        private List<Jugador> jugadores = new List<Jugador>();

        private Equipo()
        {

        }
        public Equipo(short cantidad, string nombre)
        {
            this.cantidadDeJugadores = cantidad;
            this.nombre = nombre;
        }
        public static bool operator + (Equipo e, Jugador j)
        {
            bool ok=true;
            if(e.jugadores.Count>e.cantidadDeJugadores)
            {
                ok = false;
            }
            for (int i = 0; i < e.jugadores.Count; i++)
            {
                if(e.jugadores.ElementAt(i)==j)
                {
                    ok = false;
                }
            }
            if(ok==true)
            {
                e.jugadores.Add(j);
            }
            return ok;
            
            
            
        }
       
    }
}
