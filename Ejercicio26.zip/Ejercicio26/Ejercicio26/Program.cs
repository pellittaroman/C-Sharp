﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio26
{
    class Program
    {
        static void Main(string[] args)
        {
            Random numero = new Random();
            int[] vec = new int[20];
            int aux=0;


            for (int i=0;i<20;i++)
            {
                vec[i] = numero.Next(-100, 100);
            }
            for(int i=0; i<20;i++)
            {
                Console.WriteLine("{0}", vec[i]);
            }

            Console.ReadKey();
            for (int i=0;i<19;i++)
            {
                for(int j=i+1;j<20;j++)
                {
                    if(vec[i]<vec[j])
                    {
                        
                      aux = vec[i];
                        vec[i] = vec[j];
                        vec[j]=aux;
                        
                    }
                }
            }
            for (int i = 0; i < 20; i++)
            {
                if(vec[i]>0)
                {
                    Console.Write("{0}, ", vec[i]);
                }
                
            }
            Console.ReadKey();
            for (int i = 0; i < 19; i++)
            {
                for (int j = i + 1; j < 20; j++)
                {
                    if (vec[i] > vec[j])
                    {

                        aux = vec[i];
                        vec[i] = vec[j];
                        vec[j] = aux;

                    }
                }
            }
            for (int i = 0; i < 20; i++)
            {
                if (vec[i] < 0)
                {
                    Console.Write("{0}, ", vec[i]);
                }

            }
            Console.ReadKey();
        }
    }
}
