﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ejercicio42;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodEstatico()
        {
            try
            {
                Excepcion.MiMetodo();
                
            }
            catch (Exception e)
            {

               Assert.IsInstanceOfType(e, typeof(DivideByZeroException));
                
            }
           
                
        }
        [TestMethod]
        public void PruebaConstructor()
        {
            try
            {
                new Excepcion(0);
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(UnaException));
                
            }
        }
        [TestMethod]
        public void PruebaClase()
        {
            try
            {
                new Class1();
            }
            catch (Exception e)
            {

                Assert.IsInstanceOfType(e,typeof(MiException));
            }
        }
    }
}
