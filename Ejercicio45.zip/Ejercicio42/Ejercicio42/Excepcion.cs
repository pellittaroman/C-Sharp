﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio42
{
    public class Excepcion
    {
        public static void MiMetodo()
        {
            try
            {
                int num = 0;
                int resultado = 8 / num;
            }
            catch (DivideByZeroException e)
            {

                throw e;
            }
        }
        private Excepcion()
        {
            try
            {
                Excepcion.MiMetodo();
            }
            catch (DivideByZeroException e)
            {

                throw e;
            }
        }
        public Excepcion(int  a)
        {
            try
            {
                new Excepcion();
            }
            catch (DivideByZeroException e)
            {

                throw new UnaException("divide por cero", e); 
            }
        }
    }
}
