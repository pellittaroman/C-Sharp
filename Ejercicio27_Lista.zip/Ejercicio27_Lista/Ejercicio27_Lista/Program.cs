﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio27_Lista
{
    class Program
    {
        static void Main(string[] args)
        {
            Random numero = new Random();
            List<int> vec = new List<int>();
            int aux = 0;


            for (int i = 0; i < 20; i++)
            {
                vec.Add(numero.Next(-100, 100));
            }
            for (int i = 0; i < 20; i++)
            {
                Console.Write(vec[i] + ", ");
            }

            Console.ReadKey();
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            for (int i = 0; i < 19; i++)
            {
                for (int j = i + 1; j < 20; j++)
                {
                    if (vec[i] < vec[j])
                    {

                        aux = vec[i];
                        vec[i] = vec[j];
                        vec[j] = aux;

                    }
                }
            }
            for (int i = 0; i < 20; i++)
            {
                if (vec[i] > 0)
                {
                    Console.Write(vec[i] + ", ");
                }

            }
            Console.ReadKey();
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            for (int i = 0; i < 19; i++)
            {
                for (int j = i + 1; j < 20; j++)
                {
                    if (vec[i] > vec[j])
                    {

                        aux = vec[i];
                        vec[i] = vec[j];
                        vec[j] = aux;

                    }
                }
            }
            for (int i = 0; i < 20; i++)
            {
                if (vec[i] < 0)
                {
                    Console.Write(vec[i] + ", ");
                }

            }
            Console.ReadKey();
        }
    }
}
