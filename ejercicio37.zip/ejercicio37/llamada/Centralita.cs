﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace llamada
{
    public class Centralita
    {
        private List<Llamada> listaDeLlamadas;
        protected string razonSocial;

        public float GananciaPorLocal
        {
            get
            {
                return this.CalcularGanancia(TipoDeLlamada.Local);
            }
        }
        public float GananciaPorProvicial
        {
            get
            {
                return this.CalcularGanancia(TipoDeLlamada.Provincial);
            }
        }
        public float GananciaTotal
        {
            get
            {
                return this.CalcularGanancia(TipoDeLlamada.Todas);
            }
        }
        public List<Llamada> Llamadas
        {
            get
            {
                return this.listaDeLlamadas;
            }
        }
        private float CalcularGanancia(TipoDeLlamada tipo)
        {
            float ganancia = 0;
            foreach (Llamada b in this.Llamadas)
            {
                switch (tipo)
                {
                    case TipoDeLlamada.Local:
                        if (b is Local)
                        {
                            Local aux = (Local)b;
                            ganancia = ganancia + aux.CostoLlamada;
                        }

                        break;
                    case TipoDeLlamada.Provincial:
                        if (b is Provincial)
                        {
                            Provincial aux = (Provincial)b;
                            ganancia = ganancia + aux.CostoLlamada;
                        }
                        break;
                    case TipoDeLlamada.Todas:
                        if (b is Provincial)
                        {
                            Provincial aux = (Provincial)b;
                            ganancia = ganancia + aux.CostoLlamada;
                        }
                        else
                        {
                            Local aux = (Local)b;
                            ganancia = ganancia + aux.CostoLlamada;
                        }

                        break;
                }
            
            }
            return ganancia;

        }
               
        //mostrar
        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(String.Format("Razon social: {0}", this.razonSocial));
            sb.AppendLine(String.Format("Ganancia Total: {0}", this.GananciaTotal));
            sb.AppendLine(String.Format("Ganancia por Llamadas Locales: {0}", this.GananciaPorLocal));
            sb.AppendLine(String.Format("Ganancia por Llamadas Provinciales: {0}", this.GananciaPorProvicial));
            sb.AppendLine("Detalle de Llamadas\n\n");
            foreach (Llamada a in this.Llamadas)
            {
                if(a is Local)
                {
                    Local aux = (Local)a;
                    sb.AppendLine(aux.Mostrar());
                }
                else
                {
                    Provincial aux = (Provincial)a;
                    sb.AppendLine(aux.Mostrar());
                }
            }


            return sb.ToString(); 
        }
        public void OrdenarLlamadas()
        {
            this.listaDeLlamadas.Sort(Llamada.OrdenarPorDuracion);
        }
        public Centralita()
        {
            this.listaDeLlamadas = new List<Llamada>();
        }
        public Centralita(string nombreEmpresa)
            : this()
        {
            this.razonSocial = nombreEmpresa;
        }

        
    }
}
