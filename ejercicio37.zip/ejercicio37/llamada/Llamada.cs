﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace llamada
{
    #region Enumerado
    public enum TipoDeLlamada
    {
        Local,
        Provincial,
        Todas,
    }
    #endregion
    public class Llamada
    {
        #region Atributos
        protected float duracion;
        protected string nroOrigen;
        protected string nroDestino;
        #endregion
        #region Propiedades
        public float Duracion
        {
            get
            {
                return this.duracion;
            }
        }
        public string NroOrigen
        {
            get
            {
                return this.nroOrigen;
            }
        }

        public string NroDestino
        {
            get
            {
                return this.nroDestino;
            }
        }
        



        #endregion
        #region Contructores
        public Llamada(float duracion, string nroDestino, string nroOrigen)
        {
            this.duracion = duracion;
            this.nroDestino = nroDestino;
            this.nroOrigen = nroOrigen;
        }
        #endregion
        #region Metodos
        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(string.Format("Numero de Origen: {0}", this.NroOrigen));
            sb.AppendLine(string.Format("Numero de Destino: {0}", this.NroDestino));
            sb.AppendLine(string.Format("Duracion= {0}", this.Duracion));

            return sb.ToString();
        }

        public static int OrdenarPorDuracion(Llamada llamada1, Llamada llamada2)
        {
            int retorno;
            if (llamada1.duracion < llamada2.duracion)
            {
                retorno = -1;
            }
            else
            {
                if (llamada1.duracion == llamada2.duracion)
                {
                    retorno = 0;
                }
                else
                {
                    retorno = 1;
                }
            }
            return retorno;
        }
        #endregion
    }
}
