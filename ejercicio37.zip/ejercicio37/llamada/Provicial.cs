﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace llamada
{
    public class Provincial : Llamada
    {
        #region ENUMERADO
        public enum Franja
        {
            Franja_1,
            Franja_2,
            Franja_3,
        }
        #endregion
        #region Atributos
        protected Franja franjaHoraria;
        #endregion
        #region Propiedades
        public float CostoLlamada
        {
            get
            {
                return this.CalcularCosto();
            }
        }
        #endregion 
        #region Metodos
        private float CalcularCosto()
        {
            float costoFranja = 0;
            switch (franjaHoraria)
            {
                case Franja.Franja_1:
                    costoFranja = 0.99f;
                    break;
                case Franja.Franja_2:
                    costoFranja = 1.25f;
                    break;
                case Franja.Franja_3:
                    costoFranja = 0.66f;
                    break;

            }
            return Duracion * costoFranja;
        }
        //funcion mostrar 
        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.AppendLine(string.Format("Franja horaria: {0}", this.franjaHoraria));
            sb.AppendLine(string.Format("Costo de Llamada: {0}", this.CostoLlamada));
            return sb.ToString();
        }
        #endregion
        #region Constructores
        //constructores
        public Provincial(Llamada llamada, Franja miFranja)
            : this(llamada.NroOrigen, llamada.Duracion, llamada.NroDestino, miFranja)
        {

        }
        public Provincial(string origen, float duracion, string destino, Franja miFranja)
            : base(duracion, destino, origen)
        {
            this.franjaHoraria = miFranja;
        }
        #endregion
    }
}
