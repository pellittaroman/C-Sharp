﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio15
{
    class Program
    {
        static void Main(string[] args)
        {
            char res;
            double num1;
            double num2;
            double resultado;
            char operando;

            do
            {
                Console.WriteLine("Ingrese operacion");
                operando = char.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese Numero 1");
                num1 = double.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese Numero 2");
                num2 = double.Parse(Console.ReadLine());
                resultado = Calculadora.Calcular(num1, num2, operando);
                Calculadora.Mostrar(resultado);
                Console.WriteLine("Desea continuar(S/N)");
                res = char.Parse(Console.ReadLine());
                res = char.ToLower(res);
            } while (res != 'n');
        }
    }
}
