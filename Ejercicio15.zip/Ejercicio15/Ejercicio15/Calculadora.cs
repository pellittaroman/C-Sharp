﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio15
{
    public class Calculadora
    {
        public static void Mostrar (double res)
        {
            Console.WriteLine("El resultado es " + res);
        }
        public static double Calcular(double a, double b, char t)
        {
            double retorno=0;


            if(t=='/')
            {
                bool ok= Calculadora.Validar(b);
                if(ok==true)
                {
                    retorno = a / b;
                }
            }
            if(t=='+')
            {
                retorno = a + b;
            }
            if(t=='-')
            {
                retorno = a - b;
            }
            if(t=='*')
            {
                retorno = a * b;
            }

            return retorno;
        }
        private static bool Validar(double d)
        {
            bool retorno = true;
            if(d== 0)
            {
                retorno = false;
            }
            return retorno;
        }
    }
}
