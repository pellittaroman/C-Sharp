﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1,num2, num3, num4, num5, num6, num7, num8, num9, num0;
            int maximo = 100;
            int minimo = -100;
            int max = -101;
            int min = 101;
            int acumulador = 0;
            int contador = 0;
            int promedio = 0;
           
                Console.WriteLine("Ingrese numero: ");
                num1 = int.Parse(Console.ReadLine());
                if(Validacion.validar(num1, minimo, maximo))
                {
                    if(num1>max)
                    {
                        max = num1;
                    }
                    if(num1<min)
                    {
                        min = num1;
                    }
                    contador++;
                    acumulador = acumulador + num1;    
                }
            Console.WriteLine("Ingrese numero: ");
            num2 = int.Parse(Console.ReadLine());
            if (Validacion.validar(num2, minimo, maximo))
            {
                if (num2 > max)
                {
                    max = num2;
                }
                if (num2 < min)
                {
                    min = num2;
                }
                contador++;
                acumulador = acumulador + num2;
            }
            Console.WriteLine("Ingrese numero: ");
            num3 = int.Parse(Console.ReadLine());
            if (Validacion.validar(num3, minimo, maximo))
            {
                if (num3 > max)
                {
                    max = num3;
                }
                if (num3 < min)
                {
                    min = num3;
                }
                contador++;
                acumulador = acumulador + num3;
            }
            
            Console.WriteLine("Ingrese numero: ");
            num4 = int.Parse(Console.ReadLine());
            if (Validacion.validar(num4, minimo, maximo))
            {
                if (num4 > max)
                {
                    max = num4;
                }
                if (num4 < min)
                {
                    min = num4;
                }
                contador++;
                acumulador = acumulador + num4;
            }
            Console.WriteLine("Ingrese numero: ");
            num5 = int.Parse(Console.ReadLine());
            if (Validacion.validar(num5, minimo, maximo))
            {
                if (num5 > max)
                {
                    max = num5;
                }
                if (num5< min)
                {
                    min = num5;
                }
                contador++;
                acumulador = acumulador + num5;
            }
            Console.WriteLine("Ingrese numero: ");
            num6 = int.Parse(Console.ReadLine());
            if (Validacion.validar(num6, minimo, maximo))
            {
                if (num6 > max)
                {
                    max = num6;
                }
                if (num6 < min)
                {
                    min = num6;
                }
                contador++;
                acumulador = acumulador + num6;
            }
            Console.WriteLine("Ingrese numero: ");
            num7 = int.Parse(Console.ReadLine());
            if (Validacion.validar(num7, minimo, maximo))
            {
                if (num7 > max)
                {
                    max = num7;
                }
                if (num7 < min)
                {
                    min = num7;
                }
                contador++;
                acumulador = acumulador + num7;
            }
            Console.WriteLine("Ingrese numero: ");
            num8 = int.Parse(Console.ReadLine());
            if (Validacion.validar(num8, minimo, maximo))
            {
                if (num8 > max)
                {
                    max = num8;
                }
                if (num8 < min)
                {
                    min = num8;
                }
                contador++;
                acumulador = acumulador + num8;
            }
            Console.WriteLine("Ingrese numero: ");
            num9 = int.Parse(Console.ReadLine());
            if (Validacion.validar(num9, minimo, maximo))
            {
                if (num9 > max)
                {
                    max = num9;
                }
                if (num9 < min)
                {
                    min = num9;
                }
                contador++;
                acumulador = acumulador + num9;
            }
            Console.WriteLine("Ingrese numero: ");
            num0 = int.Parse(Console.ReadLine());
            if (Validacion.validar(num0, minimo, maximo))
            {
                if (num0 > max)
                {
                    max = num0;
                }
                if (num0 < min)
                {
                    min = num0;
                }
                contador++;
                acumulador = acumulador + num0;
            }

            promedio = acumulador / contador;

            Console.WriteLine("El Promedio es "+ promedio);
            Console.WriteLine("El maximo es "+ max);
            Console.WriteLine("El minimo es "+ min);
            Console.ReadKey();


        }
    }
}
