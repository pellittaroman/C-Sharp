﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11
{
    public class Validacion
    {
        public static bool validar(int valor,int minimo,int maximo)
        {
            bool retorno = false;
            if(valor>=minimo&&valor<=maximo)
            {
                retorno = true;
            }

            return retorno;
        }
    }
}
