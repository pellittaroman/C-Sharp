﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio14
{
    class Program
    {
        static void Main(string[] args)
        {
            double cuadrado;
            double triangulob;
            double trianguloh;
            double circulo;
            Console.WriteLine("Ingrese el lado de un cuadrado");
            cuadrado = double.Parse(Console.ReadLine());
            cuadrado = CalculoDeArea.CalcularCuadrado(cuadrado);
            Console.WriteLine("El area de dicho cuadrado es " + cuadrado);
            Console.WriteLine("");
            Console.WriteLine("Ingrese el radio de un circulo");
            circulo = double.Parse(Console.ReadLine());
            circulo = CalculoDeArea.CalcularCirculo(circulo);
            Console.WriteLine("El area de dicho circulo es " + circulo);
            Console.WriteLine("");
            Console.WriteLine("Ingrese la base del triangulo");
            triangulob = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese la altura del triangulo");
            trianguloh = double.Parse(Console.ReadLine());
            triangulob = CalculoDeArea.CalcularTriangulo(triangulob,trianguloh);
            Console.WriteLine("El area de dicho cuadrado es " + triangulob);
            Console.ReadKey();

        }
    }
}
