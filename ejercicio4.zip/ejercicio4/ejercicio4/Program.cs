﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio4
{
    public class Program
    {
        static void Main(string[] args)
        {
            int suma=0;
            for(int i=3;i<10000; i++)
            {
                suma = 0;
                for (int j=1; j < i;j++)
                {
                    
                    if(i%j==0)
                    {
                     suma = suma + j;

                    }
                }
                if(suma==i)
                {
                    Console.WriteLine(i);
                }
            }
            Console.ReadKey();
        }
    }
}
