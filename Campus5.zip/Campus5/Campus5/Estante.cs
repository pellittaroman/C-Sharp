using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Campus5
{
  class Estante
  {
    protected int _ubicacion;
    protected int _capacidad;
    protected Producto[] _productos;

    private Estante(int capacidad)
    {
      this._productos = new Producto[capacidad];
    }

    public Estante(int capacidad, int ubicacion)
        : this(capacidad)
    {
      this._capacidad = capacidad;
      this._ubicacion = ubicacion;
    }
    public Producto[] GetProductos()
    {
      return this._productos;
    }

    public static string MostrarEstante(Estante e)
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Capacidad: " + e._capacidad);
      foreach (Producto p in e._productos)
      {
        if (!(((Object)p) == null))
        {
          sb.AppendLine(Producto.MostrarProducto(p));
        }
      }

      return sb.ToString();
    }

    public static bool operator ==(Estante est, Producto prod)
    {
      foreach (Producto p in est._productos)
      {
        if (!Object.ReferenceEquals(null, p))
        {
          if (p == prod)
            return true;
        }
      }

      return false;
    }

    public static bool operator !=(Estante est, Producto prod)
    {
      return !(est == prod);
    }
    public static bool operator +(Estante est, Producto prod)
    {
      
      if (est != prod)
      {
        
        for (int i = 0; i < est._productos.Length; i++)
        {
          if (Object.ReferenceEquals(null, est._productos[i]))
          {
            
            est._productos[i] = prod;
            return true;
          }
        }
      }

      return false;
    }

   
    public static Estante operator -(Estante est, Producto prod)
    {
      for (int i = 0; i < est._productos.Length; i++)
      {
        Producto p = est._productos[i];
        if (!p.Equals(null))
        {
          if (p == prod)
          {
            est._productos[i] = null;
            break;
          }
        }
      }

      return est;
    }
  }
}

