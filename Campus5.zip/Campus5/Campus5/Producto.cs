using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Campus5
{
  public class Producto
  {
    protected string _codigoDeBarra;
    protected string _marca;
    protected float _precio;

    public Producto(string marca, string codigo, float precio)
    {
      this._marca = marca;
      this._codigoDeBarra = codigo;
      this._precio = precio;
    }


    public static string MostrarProducto (Producto p)
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(String.Format("Marca {0}", p._marca));
      sb.AppendLine(String.Format("Código de Barra {0}", p._codigoDeBarra));
      sb.AppendLine(String.Format("Precio {0}", p._precio));
      return sb.ToString();
    }



    public static bool operator ==(Producto p1, Producto p2)
    {
      if (p1._marca == p2._marca && p1._codigoDeBarra == p2._codigoDeBarra)
        return true;
      else
        return false;
    }



    public static bool operator !=(Producto p1, Producto p2)
    {
      return !(p1 == p2);
    }


    public static bool operator ==(Producto p1, string marca)
    {
      return (p1._marca == marca);
    }


    public static bool operator !=(Producto p1, string marca)
    {
      return !(p1 == marca);
    }


    public static explicit operator string(Producto p)
    {
      return p._codigoDeBarra;
    }


    public  string GetMarca()
    {
      return this._marca;

      
    }
    public  float GetPrecio()
    {
       return this._precio;
      
    }

  }
}
