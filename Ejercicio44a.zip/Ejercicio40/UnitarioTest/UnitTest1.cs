﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using llamada;

namespace UnitarioTest
{
    [TestClass]
    public class UnitTest1
    {
            [TestMethod]
            public void TestMethod1()
            {
                //Arrange
                Centralita a;
                //Act
                a = new Centralita();
                //Assert
                Assert.IsNotNull(a);
            }
            [TestMethod]
            public void LlamadasLocales()
            {
                //arrange
                Llamada a;
                Llamada b;
                Centralita c;
                //act
                a = new Local("origen", 2, "destino", 1.75f);
                b = new Local("origen", 12, "destino", 3.55f);
                c = new Centralita();
                //assert
                try
                {
                    c += a;
                    c += b;
                }
                catch (Exception e)
                {
                    Assert.IsInstanceOfType(e, typeof(CentralitaException));
                }
            }
            [TestMethod]
            public void LlamadaProvincial()
            {
                //arrange
                Llamada a;
                Llamada b;
                Centralita c;
                //act
                a = new Provincial("origen", 2, "destino", Provincial.Franja.Franja_1);
                b = new Provincial("origen", 12, "destino", Provincial.Franja.Franja_3);
                c = new Centralita();
                //assert
                try
                {
                    c += a;
                    c += b;
                }
                catch (Exception e)
                {
                    Assert.IsInstanceOfType(e, typeof(CentralitaException));
                }
            }
            [TestMethod]
            public void LlamadasDistintas()
            {
                Centralita c = new Centralita("Centralita");
                Llamada l1 = new Provincial("Origen", 23, "Destino", Provincial.Franja.Franja_1);
                Llamada l2 = new Provincial("Origen", 53, "Destino", Provincial.Franja.Franja_3);
                Llamada l3 = new Local("Origen", 23, "Destino", 23);
                Llamada l4 = new Local("Origen", 53, "Destino", 43);

                Assert.IsTrue(l1 == l2);
                Assert.IsFalse(l1 == l3);
                Assert.IsFalse(l1 == l4);
                Assert.IsFalse(l2 == l3);
                Assert.IsFalse(l2 == l4);
                Assert.IsTrue(l3 == l4);
            }
        }
    }

