﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio12
{
    class Program
    {
        static void Main(string[] args)
        {
            int acumulador = 0;
            int numero;
            char res;
            bool ok;
            do
            {
                Console.WriteLine("Ingrese numero a sumar:");
                numero = int.Parse(Console.ReadLine());
                acumulador = acumulador + numero;
                Console.WriteLine("Desea seguir agregando numeros(S/N)?");
                res = char.Parse(Console.ReadLine());
                res = char.ToLower(res);
                ok = ValidarRespuesta.ValidaS_N(res);
                while (ok == false)
                {
                    Console.WriteLine("Desea seguir agregando numeros(S/N)?");
                    res = char.Parse(Console.ReadLine());
                    res = char.ToLower(res);
                    ok =ValidarRespuesta.ValidaS_N(res);
                }

            } while (res=='s');
            Console.WriteLine("La suma Total es " + acumulador);
            Console.ReadKey();
        }
    }
}
