﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio20
{
    public class Dolar
    {
        private double cantidad;
        private static float cotizacionRespDolar;
        static Dolar()
        {

            Dolar.cotizacionRespDolar = 1;
        }
        public Dolar(double cantidad)
        {
            this.cantidad = cantidad;
        }
        public Dolar(double cantidad, float cotizacion)
        {
            this.cantidad = cantidad;
            Dolar.cotizacionRespDolar = cotizacion;
        }
        public double GetCantidad()
        {

            return this.cantidad;
        }
        public static float GetCotizacion()
        {
            return Dolar.cotizacionRespDolar;
        }
        public static implicit operator Dolar(double d)
        {
            return new Dolar(d);
        }
        public static explicit operator Pesos(Dolar d)
        {
            return new Pesos(d.cantidad * Euro.GetCotizacion() * Pesos.GetCotizacion());
        }
        public static explicit operator Euro(Dolar d)
        {
            return new Euro(d.cantidad * Euro.GetCotizacion());
        }
        public static Dolar operator +(Dolar d, Euro e)
        {
            Dolar aux = new Dolar(d.cantidad + ((Dolar)e).cantidad);
            return aux;
        }

        public static Dolar operator +(Dolar d, Pesos p)
        {
            Dolar aux = new Dolar(d.cantidad + ((Dolar)p).cantidad);
            return aux;
        }

        public static Dolar operator -(Dolar d, Euro e)
        {
            Dolar aux = new Dolar(d.cantidad - ((Dolar)e).cantidad);
            return aux;
        }

        public static Dolar operator -(Dolar d, Pesos p)
        {
            Dolar aux = new Dolar(d.cantidad - ((Dolar)p).cantidad);
            return aux;
        }
        public static bool operator ==(Dolar p1, Dolar p2)
        {
            return p1.cantidad == p2.cantidad;
        }

        public static bool operator !=(Dolar p1, Dolar p2)
        {
            return !(p1 == p2);
        }

        public static bool operator ==(Dolar p, Euro e)
        {
            return p == (Dolar)e;
        }

        public static bool operator !=(Dolar d, Euro e)
        {
            return !(d == e);
        }

        public static bool operator ==(Dolar d, Pesos p)
        {
            return d ==(Dolar) p;
        }
  
        public static bool operator !=(Dolar d, Pesos p)
        {
            {
                return !(d == p);

            }
        }

    }
}
