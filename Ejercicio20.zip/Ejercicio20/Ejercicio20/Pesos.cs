﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio20
{
    public class Pesos
    {
        private double cantidad;
        private static float cotizacionRespDolar;
        static  Pesos()
        {
            
            Pesos.cotizacionRespDolar =(float) 17.55;
        }
        public Pesos(double cantidad)
        {
            this.cantidad = cantidad;
        }
        public Pesos(double cantidad,float cotizacion)
        {
            this.cantidad = cantidad;
            Pesos.cotizacionRespDolar = cotizacion;
        }
        public double GetCantidad()
        {
            return this.cantidad;
        }
        public static float GetCotizacion()
        {
            return Pesos.cotizacionRespDolar;
        }
        public static explicit operator Dolar(Pesos p)
        {
            Dolar nuevo = new Dolar(p.cantidad / p.GetCantidad());
            
            return nuevo;
            
        }
        public static explicit operator Euro(Pesos p)
        {
            Euro aux = new Euro((p.cantidad / Pesos.cotizacionRespDolar) * Euro.GetCotizacion());
            return aux;
        }
        public static implicit operator Pesos(double p)
        {
            return new Pesos(p);
        }
         public static Pesos operator +(Pesos p, Euro e)
        {
            Pesos aux = new Pesos(p.cantidad + ((Pesos)e).cantidad);
            return aux;
        }

        public static Pesos operator +(Pesos p, Dolar d)
        {
            Pesos aux = new Pesos(p.cantidad + ((Pesos)d).cantidad);
            return aux;
        }

        public static Pesos operator -(Pesos p, Euro e)
        {
            Pesos aux = new Pesos(p.cantidad - ((Pesos)e).cantidad);
            return aux;
        }

        public static Pesos operator -(Pesos p, Dolar d)
        {
            Pesos aux = new Pesos(p.cantidad - ((Pesos)d).cantidad);
            return aux;
        }
        public static bool operator ==(Pesos p1, Pesos p2)
        {
            return p1.cantidad == p2.cantidad;
        }

        public static bool operator !=(Pesos p1, Pesos p2)
        {
            return !(p1 == p2);
        }

        public static bool operator ==(Pesos p, Euro e)
        {
            return p == (Pesos)e;
        }

        public static bool operator !=(Pesos p, Euro e)
        {
            return !(p == e);
        }

        public static bool operator ==(Pesos p, Dolar d)
        {
            return p == (Pesos)d;
        }

        public static bool operator !=(Pesos p, Dolar d)
        {
            return !(p == d);

        }    


    }
}
