﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio13
{
    public class Conversor
    {
        public static string DecimalBinario(double d)
        {
            string cadena = "";
            if (d > 0)
            {
                
                while (d >= 2)
                {
                    if (d % 2 == 0)
                    {
                        cadena = "0" + cadena;
                    }
                    else
                    {
                        cadena = "1" + cadena;
                    }
                    d = (int)(d / 2);
                }
                if(d==1)
                {
                    cadena = "1" + cadena;
                }
                else
                {
                    cadena = "0" + cadena;
                }
            }

            return cadena;
        }
        
        public static double BinarioDecimal(string b)
        {

            double exponente = b.Length - 1;
            double num_decimal = 0;

            for (int i = 0; i < b.Length; i++)
            {
                if (double.Parse(b.Substring(i, 1)) == 1)
                {
                    num_decimal = num_decimal + double.Parse(System.Math.Pow(2,exponente).ToString());
                }
                exponente--;
            }
            return num_decimal;


        }
        

    }
}
