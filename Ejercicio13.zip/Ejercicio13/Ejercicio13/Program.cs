﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio13
{
    class Program
    {
        static void Main(string[] args)
        {
            string Binario;
            double Decimal;
            Console.WriteLine("Ingrese numero decimal: ");
            Decimal = double.Parse(Console.ReadLine());
            Binario = Conversor.DecimalBinario(Decimal);
            Console.WriteLine("" + Binario);
            Console.ReadKey();
            Console.WriteLine("Ingrese numero binario: ");
            Binario = Console.ReadLine();
            Decimal = Conversor.BinarioDecimal(Binario);
            Console.WriteLine("" + Decimal);
            Console.ReadKey();






        }
    }
}
