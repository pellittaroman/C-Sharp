using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;

namespace Entidades
{
  public class SerealizarXml<T> : IArchivos<T>
  {
   

    public bool Guardar(string rutaArchivo,T datos)
    {
      bool ok = true;
      XmlTextWriter writer = null;
      try
      {
        writer = new XmlTextWriter(rutaArchivo, null);
        XmlSerializer xml = new XmlSerializer(typeof(T));
        xml.Serialize(writer, datos);
      }
      catch (Exception a)
      {

        throw new ErrorArchivoException(a.Message);
      }
      finally
      {
                if (writer != null)
                {
                    writer.Close();
                }
       
      }

      return ok;
    }
    public T Leer(string rutaArchivo)
    {
      T aux;
      
      XmlSerializer xml = new XmlSerializer(typeof(T));
      XmlTextReader reader=new XmlTextReader("");
      try
      {
        reader = new XmlTextReader(rutaArchivo);
        aux =(T) xml.Deserialize(reader);
      }
      catch (Exception a)
      {

                throw new ErrorArchivoException(a.Message);
            }
      finally
      {
                if(reader!=null)
        reader.Close();
      }
      return aux;
    }
  }
}
