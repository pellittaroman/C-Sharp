using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace Entidades
{
  public class Dao
  {

        private SqlConnection conexion;
        private SqlCommand comando;
        private static string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=Votacion;Integrated Security= true";

    public Votacion Leer(string RutaDeArchivo)
    {
            throw new NotImplementedException();
    }
    public bool Guardar(Votacion votacion)
    {
            bool ok = true;
            try
            {
                conexion = new SqlConnection(connectionString);
                comando = new SqlCommand();
                comando.Connection = conexion;
                comando.CommandType = System.Data.CommandType.Text;
                comando.CommandText = "INSERT INTO Votaciones(NombreLey,Afirmativos,Negativos,Abstencion)Values('" + votacion.NombreLey + "','" + votacion.ContadorAfirmativo + "','" + votacion.ContadorNegativo + "','" + votacion.ContadorAbstencion + "')";
                conexion.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception e)
            {

                throw e;
            }
            finally
            {
                
                conexion.Close();
            }

            return ok;
        }
    }
}
