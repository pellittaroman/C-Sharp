﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;
using System.Collections.Generic;


namespace TestUnitarios
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Votacion vot=null;
           
            SerealizarXml<Votacion> xml = new SerealizarXml<Votacion>();
            try
            {
                xml.Guardar("", vot);
                Assert.Fail();
            }
            catch (Exception a)
            {

                Assert.IsInstanceOfType(a, typeof(ErrorArchivoException));
            }
        }
        [TestMethod()]
        public void PruebaEvento()
        {
            Dictionary<string, Votacion.EVoto> senadores = new Dictionary<string, Votacion.EVoto>();
            senadores.Add("0", Votacion.EVoto.Esperando);
            senadores.Add("1", Votacion.EVoto.Esperando);
            senadores.Add("2", Votacion.EVoto.Esperando);
            Votacion v = new Votacion("nueva ley", senadores);
            v.EventoVotoEfectuado += Manejador;
            v.Simular();

            Assert.IsTrue(v.ContadorAbstencion + v.ContadorAfirmativo + v.ContadorNegativo == 3);
        }
        public void Manejador(string senador,Votacion.EVoto voto)
        { }
    }
}
