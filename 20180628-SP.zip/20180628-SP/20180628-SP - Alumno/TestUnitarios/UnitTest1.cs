﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;


namespace TestUnitarios
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Votacion vot=null;
           
            SerealizarXml<Votacion> xml = new SerealizarXml<Votacion>();
            try
            {
                xml.Guardar("", vot);
                Assert.Fail();
            }
            catch (Exception a)
            {

                Assert.IsInstanceOfType(a, typeof(ErrorArchivoException));
            }
        }
    }
}
